"""RTX-side modular monolith."""
